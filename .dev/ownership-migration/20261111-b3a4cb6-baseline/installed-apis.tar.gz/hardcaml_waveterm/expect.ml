open Base
open Hardcaml_waveterm_kernel

module type S = Expect_intf.S

let serialize_expect_test_output =
  lazy
    (match Sys.getenv "EXPECT_TEST_WAVEFORM" with
     | None -> `none
     | Some "1" | Some "true" -> `by_name
     | Some "digest" -> `by_digest
     | _ -> `none)
;;

let expect
  ?display_rules
  ?display_width
  ?display_height
  ?display_values
  ?wave_width
  ?signals_width
  ?start_cycle
  ?signals_alignment
  ?(show_digest = true)
  ?serialize_to
  t
  =
  let extension = "hardcamlwaveform" in
  Waveform.print
    ?display_rules
    ?display_width
    ?display_height
    ?display_values
    ?wave_width
    ?signals_width
    ?start_cycle
    ?signals_alignment
    t;
  let digest = lazy (Waveform_digest.to_hex_string (Waveform_digest.create t)) in
  if show_digest then Stdio.print_endline (Lazy.force digest);
  let serialize_to =
    match serialize_to, Lazy.force serialize_expect_test_output with
    | (Some _ | None), `by_digest -> Some (Lazy.force digest)
    | None, (`none | `by_name) -> None
    | Some _, `none -> None
    | Some name, `by_name -> Some name
  in
  Option.iter serialize_to ~f:(fun serialize_to ->
    let serialize_to =
      if String.equal (Stdlib.Filename.extension serialize_to) extension
      then serialize_to
      else Printf.sprintf "%s.%s" serialize_to extension
    in
    Serialize_waveform.marshall t serialize_to)
;;

let expect_exact
  ?display_rules
  ?(display_width = 90)
  ?display_height
  ?display_values
  ?wave_width
  ?signals_width
  ?start_cycle
  ?signals_alignment
  ?show_digest
  ?serialize_to
  t
  =
  Stdio.print_endline "";
  expect
    ?display_rules
    ~display_width
    ?display_height
    ?display_values
    ?wave_width
    ?signals_width
    ?start_cycle
    ?signals_alignment
    ?show_digest
    ?serialize_to
    t
;;
