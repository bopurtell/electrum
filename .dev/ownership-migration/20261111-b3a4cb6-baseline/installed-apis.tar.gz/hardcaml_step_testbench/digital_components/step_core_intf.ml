(** This module is the heart of the step testbench, the [Computation.t] type and the
    [Runner.t] to is used to represent the execution of the computation. *)

open Core

module type Step_core = sig
  module Computation : sig
    module Effect_ops : sig
      type ('a, 'i, 'o, 'effect) t =
        | Current_input : ('i aliased_many, 'i, 'o, 'effect) t
        | Next_period :
            Source_code_position.t * 'o
            -> ('i aliased_many, 'i, 'o, 'effect) t
        | Spawn :
            { child : ('i_c, 'o_c) Component.t
            ; child_finished : (_, 'o_c) Component_finished.t Event.t
            ; child_input : parent:'i -> 'i_c
            ; include_child_output : parent:'o -> child:'o_c -> 'o
            }
            -> (unit aliased_many, 'i, 'o, 'effect) t
    end

    module Eff :
      Handled_effect.S2
      with type ('a, 'i, 'o, 'eff) ops := ('a, 'i, 'o, 'eff) Effect_ops.t

    type ('a, 'i, 'o) t = T of (('i, 'o) Eff.Handler.t @ local -> 'a) [@@unboxed]
  end

  (* A [Runner.t] is a stateful value that can run a [Computation.t] one step at a time,
     and has an interface like [Component.S]. *)
  module Runner : sig
    type ('i, 'o) t [@@deriving sexp_of]

    (** Traverse through the tree of children to prune the ones that are finished

        Each component tracks all of their children even if they are "finished". To
        improve performance we periodically . *)
    val prune_children : ('i, 'o) t -> unit

    val output : ('i, 'o) t -> 'o

    (** Returns true if the list of children is empty. Note that calls to prune_children
        can change the result of this function call. *)
    val has_children : ('i, 'o) t -> bool

    val create : start:('i -> ('o, 'i, 'o) Computation.t) -> output:'o -> ('i, 'o) t

    val update_state
      :  ?prune:bool
      -> update_children_after_finish:bool
      -> period:int
      -> step_number:int
      -> ('i, 'o) t
      -> 'i
      -> unit
  end
end
