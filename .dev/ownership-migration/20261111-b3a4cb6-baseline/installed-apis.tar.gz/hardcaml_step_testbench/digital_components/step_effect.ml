open! Base
include Step_effect_intf
module Component_finished = Component_finished
module Event = Event
module Runner = Step_core.Runner

module Handler = struct
  type ('i, 'o) t = ('i, 'o) Step_core.Computation.Eff.Handler.t
end

let current_input (handler : ('i, 'o) Handler.t @ local) =
  let%tydi { aliased_many = result } =
    Step_core.Computation.Eff.perform
      handler
      Step_core.Computation.Effect_ops.Current_input
  in
  result
;;

let next_step (handler : _ Handler.t @ local) here o =
  let%tydi { aliased_many = result } =
    Step_core.Computation.Eff.perform
      handler
      (Step_core.Computation.Effect_ops.Next_period (here, o))
  in
  result
;;

let thunk (handler : _ Handler.t @ local) f = f () handler

let output_forever (type i o) (handler : (i, o) Handler.t @ local) output =
  while true do
    ignore (next_step handler [%here] output : i)
  done
;;

let wait_for (handler : _ Handler.t @ local) (event : _ Event.t) ~output =
  let result = ref None in
  while Option.is_none !result do
    match Event.value event with
    | Some a -> result := Some a
    | None -> ignore (next_step handler [%here] output : 'i)
  done;
  Option.value_exn !result
;;

let wait (handler : ('i, 'o) Handler.t @ local) ~output ~until =
  let input = ref (current_input handler) in
  while not (until !input) do
    input := next_step handler [%here] output
  done
;;

let delay (handler : ('i, 'o) Handler.t @ local) output ~num_steps =
  if num_steps < 0
  then
    raise_s
      [%message "[Step_effects.delay] got negative [num_steps]" ~_:(num_steps : int)];
  for _ = 1 to num_steps do
    ignore (next_step handler [%here] output : 'i)
  done
;;

let create_component
  (type a i o)
  ?period
  ~created_at
  ~update_children_after_finish
  ~(start : (i, o) Handler.t @ local -> i -> (a, o) Component_finished.t)
  ~(input : i Data.t)
  ~(output : o Data.t)
  ()
  : (i, o) Component.t * (a, o) Component_finished.t Event.t
  =
  let component_finished = Event.create () in
  let component =
    Component.create
      (module struct
        module Input = (val input)
        module Output = (val output)

        let created_at = created_at

        type t = (Input.t, Output.t) Runner.t [@@deriving sexp_of]

        let t =
          Runner.create ~output:Output.undefined ~start:(fun i ->
            Step_core.Computation.T
              (fun handler ->
                let x = start handler i in
                Event.set_value component_finished x;
                x.output))
        ;;

        let output (t : t) _ = Runner.output t

        let update_state ?prune ~parent_period ~step_number t =
          let period = Option.value ~default:parent_period period in
          Runner.update_state ?prune ~update_children_after_finish ~period ~step_number t
        ;;

        let prune_children = Runner.prune_children
        let has_children (t : t) = Runner.has_children t
      end)
  in
  component, component_finished
;;

let spawn
  ?(update_children_after_finish = false)
  ?period
  (handler : ('i, 'o) Handler.t @ local)
  created_at
  ~start
  ~input
  ~output
  ~child_input
  ~include_child_output
  =
  let child, child_finished =
    create_component
      ?period
      ~update_children_after_finish
      ~created_at
      ~start
      ~input
      ~output
      ()
  in
  let%tydi { aliased_many = () } =
    Step_core.Computation.Eff.perform
      handler
      (Step_core.Computation.Effect_ops.Spawn
         { child; child_finished; child_input; include_child_output })
  in
  child_finished
;;
