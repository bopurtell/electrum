type token =
  | TOK_BRACKET_O
  | TOK_BRACKET_C
  | TOK_COLON
  | TOK_KW_END
  | TOK_KW_COMMENT
  | TOK_KW_SIM_COMMENT
  | TOK_COMMENT_TEXT of (
# 37 "vcd/src/parser.mly"
        string
# 12 "vcd/src/parser.ml"
)
  | TOK_KW_DATE
  | TOK_DATE_TEXT of (
# 39 "vcd/src/parser.mly"
        string
# 18 "vcd/src/parser.ml"
)
  | TOK_KW_ENDDEFINITIONS
  | TOK_KW_SCOPE
  | TOK_KW_TIMESCALE
  | TOK_KW_UPSCOPE
  | TOK_KW_VAR
  | TOK_KW_VERSION
  | TOK_VERSION_TEXT of (
# 46 "vcd/src/parser.mly"
        string
# 29 "vcd/src/parser.ml"
)
  | TOK_KW_DUMPALL
  | TOK_KW_DUMPOFF
  | TOK_KW_DUMPON
  | TOK_KW_DUMPVARS
  | TOK_KW_BEGIN of (
# 51 "vcd/src/parser.mly"
        Types.Scope.t
# 38 "vcd/src/parser.ml"
)
  | TOK_KW_FORK of (
# 52 "vcd/src/parser.mly"
        Types.Scope.t
# 43 "vcd/src/parser.ml"
)
  | TOK_KW_FUNCTION of (
# 53 "vcd/src/parser.mly"
        Types.Scope.t
# 48 "vcd/src/parser.ml"
)
  | TOK_KW_MODULE of (
# 54 "vcd/src/parser.mly"
        Types.Scope.t
# 53 "vcd/src/parser.ml"
)
  | TOK_KW_TASK of (
# 55 "vcd/src/parser.mly"
        Types.Scope.t
# 58 "vcd/src/parser.ml"
)
  | TOK_TIME_NUMBER of (
# 56 "vcd/src/parser.mly"
        int
# 63 "vcd/src/parser.ml"
)
  | TOK_TIME_UNIT of (
# 57 "vcd/src/parser.mly"
        Types.Time_unit.t
# 68 "vcd/src/parser.ml"
)
  | TOK_VAR_TYPE of (
# 58 "vcd/src/parser.mly"
        Types.Var_type.t
# 73 "vcd/src/parser.ml"
)
  | TOK_HASH
  | TOK_VALUE of (
# 60 "vcd/src/parser.mly"
        Types.Bit.t
# 79 "vcd/src/parser.ml"
)
  | TOK_BIN_NUM of (
# 61 "vcd/src/parser.mly"
        string
# 84 "vcd/src/parser.ml"
)
  | TOK_REAL_NUM of (
# 62 "vcd/src/parser.mly"
        string
# 89 "vcd/src/parser.ml"
)
  | TOK_IDENTIFIER of (
# 63 "vcd/src/parser.mly"
        string
# 94 "vcd/src/parser.ml"
)
  | TOK_DECIMAL_NUM of (
# 64 "vcd/src/parser.mly"
        int
# 99 "vcd/src/parser.ml"
)
  | EOF

open Parsing
let _ = parse_error;;
# 2 "vcd/src/parser.mly"

open Types

let parse_bin_vector s =
  let len = String.length s in
  let rec loop i acc =
    if i >= len then List.rev acc
    else begin
      let b = match s.[i] with
        | '0' -> Types.Bit.V0
        | '1' -> V1
        | 'x' | 'X' -> Vx
        | 'z' | 'Z' -> Vz
        | _ -> Vx
      in
      loop (i+1) (b :: acc)
    end
  in
  (* skip leading 'b' or 'B' character *)
  loop 1 []
;;

let parse_real_value s =
  (* skip leading 'r' or 'R' character *)
  float_of_string (String.sub s 1 (String.length s - 1))
;;

# 133 "vcd/src/parser.ml"
let yytransl_const = [|
  257 (* TOK_BRACKET_O *);
  258 (* TOK_BRACKET_C *);
  259 (* TOK_COLON *);
  260 (* TOK_KW_END *);
  261 (* TOK_KW_COMMENT *);
  262 (* TOK_KW_SIM_COMMENT *);
  264 (* TOK_KW_DATE *);
  266 (* TOK_KW_ENDDEFINITIONS *);
  267 (* TOK_KW_SCOPE *);
  268 (* TOK_KW_TIMESCALE *);
  269 (* TOK_KW_UPSCOPE *);
  270 (* TOK_KW_VAR *);
  271 (* TOK_KW_VERSION *);
  273 (* TOK_KW_DUMPALL *);
  274 (* TOK_KW_DUMPOFF *);
  275 (* TOK_KW_DUMPON *);
  276 (* TOK_KW_DUMPVARS *);
  285 (* TOK_HASH *);
    0 (* EOF *);
    0|]

let yytransl_block = [|
  263 (* TOK_COMMENT_TEXT *);
  265 (* TOK_DATE_TEXT *);
  272 (* TOK_VERSION_TEXT *);
  277 (* TOK_KW_BEGIN *);
  278 (* TOK_KW_FORK *);
  279 (* TOK_KW_FUNCTION *);
  280 (* TOK_KW_MODULE *);
  281 (* TOK_KW_TASK *);
  282 (* TOK_TIME_NUMBER *);
  283 (* TOK_TIME_UNIT *);
  284 (* TOK_VAR_TYPE *);
  286 (* TOK_VALUE *);
  287 (* TOK_BIN_NUM *);
  288 (* TOK_REAL_NUM *);
  289 (* TOK_IDENTIFIER *);
  290 (* TOK_DECIMAL_NUM *);
    0|]

let yylhs = "\255\255\
\001\000\001\000\001\000\001\000\002\000\002\000\003\000\003\000\
\004\000\004\000\004\000\004\000\004\000\004\000\004\000\004\000\
\005\000\005\000\005\000\005\000\005\000\005\000\005\000\008\000\
\008\000\008\000\008\000\008\000\012\000\014\000\014\000\011\000\
\011\000\013\000\013\000\015\000\016\000\016\000\009\000\009\000\
\009\000\006\000\006\000\010\000\010\000\007\000\007\000\000\000"

let yylen = "\002\000\
\001\000\003\000\002\000\002\000\001\000\002\000\001\000\002\000\
\003\000\003\000\002\000\004\000\004\000\002\000\006\000\003\000\
\003\000\003\000\003\000\003\000\003\000\001\000\001\000\001\000\
\001\000\001\000\001\000\001\000\002\000\001\000\002\000\000\000\
\001\000\001\000\001\000\002\000\002\000\002\000\001\000\004\000\
\006\000\000\000\001\000\000\000\001\000\000\000\001\000\002\000"

let yydefred = "\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\001\000\048\000\000\000\000\000\005\000\
\007\000\022\000\023\000\034\000\035\000\043\000\000\000\000\000\
\047\000\000\000\011\000\024\000\025\000\026\000\027\000\028\000\
\000\000\000\000\014\000\000\000\045\000\000\000\000\000\030\000\
\000\000\000\000\000\000\000\000\029\000\036\000\037\000\038\000\
\004\000\000\000\006\000\003\000\008\000\009\000\021\000\010\000\
\000\000\000\000\000\000\016\000\017\000\031\000\018\000\019\000\
\020\000\002\000\012\000\013\000\000\000\000\000\000\000\000\000\
\015\000\000\000\040\000\000\000\000\000\041\000"

let yydgoto = "\002\000\
\021\000\022\000\023\000\024\000\025\000\031\000\034\000\041\000\
\079\000\046\000\047\000\026\000\027\000\049\000\028\000\029\000"

let yysindex = "\013\000\
\001\000\000\000\013\255\013\255\012\255\018\255\241\254\253\254\
\020\255\254\254\009\255\237\254\237\254\237\254\237\254\249\254\
\251\254\255\254\000\255\000\000\000\000\029\000\045\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\026\255\027\255\
\000\000\030\255\000\000\000\000\000\000\000\000\000\000\000\000\
\003\255\010\255\000\000\004\255\000\000\036\255\037\255\000\000\
\237\254\038\255\039\255\040\255\000\000\000\000\000\000\000\000\
\000\000\049\000\000\000\000\000\000\000\000\000\000\000\000\000\
\042\255\043\255\015\255\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\017\255\050\255\048\255\019\255\
\000\000\016\255\000\000\021\255\052\255\000\000"

let yyrindex = "\000\000\
\000\000\000\000\053\255\053\255\054\255\000\000\000\000\000\000\
\000\000\000\000\055\255\056\255\056\255\056\255\056\255\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\057\255\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\058\255\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000"

let yygindex = "\000\000\
\000\000\000\000\034\000\041\000\233\255\060\000\000\000\000\000\
\000\000\000\000\002\000\000\000\246\255\000\000\000\000\000\000"

let yytablesize = 337
let yytable = "\061\000\
\020\000\048\000\048\000\048\000\048\000\036\000\037\000\038\000\
\039\000\040\000\017\000\018\000\019\000\001\000\050\000\051\000\
\052\000\083\000\084\000\030\000\033\000\035\000\042\000\043\000\
\045\000\044\000\053\000\054\000\057\000\062\000\063\000\055\000\
\056\000\064\000\061\000\065\000\066\000\067\000\070\000\068\000\
\069\000\071\000\072\000\073\000\060\000\075\000\076\000\077\000\
\074\000\078\000\080\000\081\000\082\000\086\000\085\000\058\000\
\042\000\046\000\044\000\032\000\033\000\039\000\059\000\032\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\003\000\004\000\000\000\
\005\000\000\000\006\000\007\000\008\000\009\000\010\000\011\000\
\000\000\012\000\013\000\014\000\015\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\016\000\017\000\018\000\
\019\000\003\000\004\000\000\000\005\000\000\000\006\000\007\000\
\008\000\009\000\010\000\011\000\000\000\012\000\013\000\014\000\
\015\000\000\000\004\000\000\000\000\000\000\000\004\000\000\000\
\000\000\016\000\017\000\018\000\019\000\012\000\013\000\014\000\
\015\000\012\000\013\000\014\000\015\000\000\000\000\000\000\000\
\000\000\016\000\017\000\018\000\019\000\016\000\017\000\018\000\
\019\000"

let yycheck = "\023\000\
\000\000\012\000\013\000\014\000\015\000\021\001\022\001\023\001\
\024\001\025\001\030\001\031\001\032\001\001\000\013\000\014\000\
\015\000\002\001\003\001\007\001\009\001\004\001\026\001\004\001\
\016\001\028\001\034\001\033\001\000\000\004\001\004\001\033\001\
\033\001\004\001\058\000\033\001\027\001\034\001\049\000\004\001\
\004\001\004\001\004\001\004\001\000\000\004\001\004\001\033\001\
\000\000\033\001\001\001\004\001\034\001\002\001\034\001\022\000\
\004\001\004\001\004\001\004\001\004\001\004\001\022\000\004\000\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\005\001\006\001\255\255\
\008\001\255\255\010\001\011\001\012\001\013\001\014\001\015\001\
\255\255\017\001\018\001\019\001\020\001\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\029\001\030\001\031\001\
\032\001\005\001\006\001\255\255\008\001\255\255\010\001\011\001\
\012\001\013\001\014\001\015\001\255\255\017\001\018\001\019\001\
\020\001\255\255\006\001\255\255\255\255\255\255\006\001\255\255\
\255\255\029\001\030\001\031\001\032\001\017\001\018\001\019\001\
\020\001\017\001\018\001\019\001\020\001\255\255\255\255\255\255\
\255\255\029\001\030\001\031\001\032\001\029\001\030\001\031\001\
\032\001"

let yynames_const = "\
  TOK_BRACKET_O\000\
  TOK_BRACKET_C\000\
  TOK_COLON\000\
  TOK_KW_END\000\
  TOK_KW_COMMENT\000\
  TOK_KW_SIM_COMMENT\000\
  TOK_KW_DATE\000\
  TOK_KW_ENDDEFINITIONS\000\
  TOK_KW_SCOPE\000\
  TOK_KW_TIMESCALE\000\
  TOK_KW_UPSCOPE\000\
  TOK_KW_VAR\000\
  TOK_KW_VERSION\000\
  TOK_KW_DUMPALL\000\
  TOK_KW_DUMPOFF\000\
  TOK_KW_DUMPON\000\
  TOK_KW_DUMPVARS\000\
  TOK_HASH\000\
  EOF\000\
  "

let yynames_block = "\
  TOK_COMMENT_TEXT\000\
  TOK_DATE_TEXT\000\
  TOK_VERSION_TEXT\000\
  TOK_KW_BEGIN\000\
  TOK_KW_FORK\000\
  TOK_KW_FUNCTION\000\
  TOK_KW_MODULE\000\
  TOK_KW_TASK\000\
  TOK_TIME_NUMBER\000\
  TOK_TIME_UNIT\000\
  TOK_VAR_TYPE\000\
  TOK_VALUE\000\
  TOK_BIN_NUM\000\
  TOK_REAL_NUM\000\
  TOK_IDENTIFIER\000\
  TOK_DECIMAL_NUM\000\
  "

let yyact = [|
  (fun _ -> failwith "parser")
; (fun __caml_parser_env ->
    Obj.repr(
# 74 "vcd/src/parser.mly"
    ( { declarations = []; simulation_commands = [] } )
# 376 "vcd/src/parser.ml"
               : Types.t))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'declaration_commands) in
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'simulation_commands) in
    Obj.repr(
# 76 "vcd/src/parser.mly"
    ( { declarations = _1; simulation_commands = _2 } )
# 384 "vcd/src/parser.ml"
               : Types.t))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'simulation_commands) in
    Obj.repr(
# 78 "vcd/src/parser.mly"
    ( { declarations = []; simulation_commands = _1 } )
# 391 "vcd/src/parser.ml"
               : Types.t))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'declaration_commands) in
    Obj.repr(
# 80 "vcd/src/parser.mly"
    ( { declarations = _1; simulation_commands = [] } )
# 398 "vcd/src/parser.ml"
               : Types.t))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'declaration_command) in
    Obj.repr(
# 85 "vcd/src/parser.mly"
    ( [ _1 ] )
# 405 "vcd/src/parser.ml"
               : 'declaration_commands))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'declaration_commands) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'declaration_command) in
    Obj.repr(
# 87 "vcd/src/parser.mly"
    ( _1 @ [ _2 ] )
# 413 "vcd/src/parser.ml"
               : 'declaration_commands))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'simulation_command) in
    Obj.repr(
# 92 "vcd/src/parser.mly"
    ( [ _1 ] )
# 420 "vcd/src/parser.ml"
               : 'simulation_commands))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'simulation_commands) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'simulation_command) in
    Obj.repr(
# 94 "vcd/src/parser.mly"
    ( _1 @ [ _2 ] )
# 428 "vcd/src/parser.ml"
               : 'simulation_commands))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'comment_text) in
    Obj.repr(
# 99 "vcd/src/parser.mly"
    ( Comment _2 )
# 435 "vcd/src/parser.ml"
               : 'declaration_command))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'date_text) in
    Obj.repr(
# 101 "vcd/src/parser.mly"
    ( Date _2 )
# 442 "vcd/src/parser.ml"
               : 'declaration_command))
; (fun __caml_parser_env ->
    Obj.repr(
# 103 "vcd/src/parser.mly"
    ( Enddefinitions )
# 448 "vcd/src/parser.ml"
               : 'declaration_command))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 2 : 'scope_type) in
    let _3 = (Parsing.peek_val __caml_parser_env 1 : string) in
    Obj.repr(
# 105 "vcd/src/parser.mly"
    ( Scope (_2, _3) )
# 456 "vcd/src/parser.ml"
               : 'declaration_command))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 2 : int) in
    let _3 = (Parsing.peek_val __caml_parser_env 1 : Types.Time_unit.t) in
    Obj.repr(
# 107 "vcd/src/parser.mly"
    ( Timescale (_2, _3) )
# 464 "vcd/src/parser.ml"
               : 'declaration_command))
; (fun __caml_parser_env ->
    Obj.repr(
# 109 "vcd/src/parser.mly"
    ( Upscope )
# 470 "vcd/src/parser.ml"
               : 'declaration_command))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 4 : Types.Var_type.t) in
    let _3 = (Parsing.peek_val __caml_parser_env 3 : int) in
    let _4 = (Parsing.peek_val __caml_parser_env 2 : string) in
    let _5 = (Parsing.peek_val __caml_parser_env 1 : 'reference) in
    Obj.repr(
# 112 "vcd/src/parser.mly"
    ( Var { var_type = _2; var_size = _3; var_id = _4; var_ref = _5 } )
# 480 "vcd/src/parser.ml"
               : 'declaration_command))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'version_text) in
    Obj.repr(
# 114 "vcd/src/parser.mly"
    ( Version _2 )
# 487 "vcd/src/parser.ml"
               : 'declaration_command))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'value_changes_opt) in
    Obj.repr(
# 119 "vcd/src/parser.mly"
    ( Sim_dumpall _2 )
# 494 "vcd/src/parser.ml"
               : 'simulation_command))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'value_changes_opt) in
    Obj.repr(
# 121 "vcd/src/parser.mly"
    ( Sim_dumpoff _2 )
# 501 "vcd/src/parser.ml"
               : 'simulation_command))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'value_changes_opt) in
    Obj.repr(
# 123 "vcd/src/parser.mly"
    ( Sim_dumpon _2 )
# 508 "vcd/src/parser.ml"
               : 'simulation_command))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'value_changes_opt) in
    Obj.repr(
# 125 "vcd/src/parser.mly"
    ( Sim_dumpvars _2 )
# 515 "vcd/src/parser.ml"
               : 'simulation_command))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'comment_text) in
    Obj.repr(
# 127 "vcd/src/parser.mly"
    ( Sim_comment _2 )
# 522 "vcd/src/parser.ml"
               : 'simulation_command))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'simulation_time) in
    Obj.repr(
# 129 "vcd/src/parser.mly"
    ( _1 )
# 529 "vcd/src/parser.ml"
               : 'simulation_command))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'value_change) in
    Obj.repr(
# 131 "vcd/src/parser.mly"
    ( Sim_value_change _1 )
# 536 "vcd/src/parser.ml"
               : 'simulation_command))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : Types.Scope.t) in
    Obj.repr(
# 135 "vcd/src/parser.mly"
                    ( _1 )
# 543 "vcd/src/parser.ml"
               : 'scope_type))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : Types.Scope.t) in
    Obj.repr(
# 136 "vcd/src/parser.mly"
                    ( _1 )
# 550 "vcd/src/parser.ml"
               : 'scope_type))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : Types.Scope.t) in
    Obj.repr(
# 137 "vcd/src/parser.mly"
                    ( _1 )
# 557 "vcd/src/parser.ml"
               : 'scope_type))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : Types.Scope.t) in
    Obj.repr(
# 138 "vcd/src/parser.mly"
                    ( _1 )
# 564 "vcd/src/parser.ml"
               : 'scope_type))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : Types.Scope.t) in
    Obj.repr(
# 139 "vcd/src/parser.mly"
                    ( _1 )
# 571 "vcd/src/parser.ml"
               : 'scope_type))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : int) in
    Obj.repr(
# 144 "vcd/src/parser.mly"
    ( Sim_time _2 )
# 578 "vcd/src/parser.ml"
               : 'simulation_time))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'value_change) in
    Obj.repr(
# 149 "vcd/src/parser.mly"
    ( [ _1 ] )
# 585 "vcd/src/parser.ml"
               : 'value_changes))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'value_changes) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'value_change) in
    Obj.repr(
# 151 "vcd/src/parser.mly"
    ( _1 @ [ _2 ] )
# 593 "vcd/src/parser.ml"
               : 'value_changes))
; (fun __caml_parser_env ->
    Obj.repr(
# 155 "vcd/src/parser.mly"
                   ( [] )
# 599 "vcd/src/parser.ml"
               : 'value_changes_opt))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'value_changes) in
    Obj.repr(
# 156 "vcd/src/parser.mly"
                   ( _1 )
# 606 "vcd/src/parser.ml"
               : 'value_changes_opt))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'scalar_value_change) in
    Obj.repr(
# 160 "vcd/src/parser.mly"
                        ( _1 )
# 613 "vcd/src/parser.ml"
               : 'value_change))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'vector_value_change) in
    Obj.repr(
# 161 "vcd/src/parser.mly"
                        ( _1 )
# 620 "vcd/src/parser.ml"
               : 'value_change))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : Types.Bit.t) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 166 "vcd/src/parser.mly"
    ( Scalar_value (_1, _2) )
# 628 "vcd/src/parser.ml"
               : 'scalar_value_change))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : string) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 171 "vcd/src/parser.mly"
    ( Vector_value (parse_bin_vector _1, _2) )
# 636 "vcd/src/parser.ml"
               : 'vector_value_change))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : string) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 173 "vcd/src/parser.mly"
    ( Real_value (parse_real_value _1, _2) )
# 644 "vcd/src/parser.ml"
               : 'vector_value_change))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 178 "vcd/src/parser.mly"
    ( { ref_name = _1; lindex = -1; rindex = -1 } )
# 651 "vcd/src/parser.ml"
               : 'reference))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 3 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 1 : int) in
    Obj.repr(
# 180 "vcd/src/parser.mly"
    ( { ref_name = _1; lindex = _3; rindex = -1 } )
# 659 "vcd/src/parser.ml"
               : 'reference))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 5 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 3 : int) in
    let _5 = (Parsing.peek_val __caml_parser_env 1 : int) in
    Obj.repr(
# 183 "vcd/src/parser.mly"
    ( if _3 = 0 && _3 = _5
      then { ref_name = _1; lindex = -1; rindex = -1 }
      else { ref_name = _1; lindex = _3; rindex = _5 } )
# 670 "vcd/src/parser.ml"
               : 'reference))
; (fun __caml_parser_env ->
    Obj.repr(
# 189 "vcd/src/parser.mly"
                       ( "" )
# 676 "vcd/src/parser.ml"
               : 'comment_text))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 190 "vcd/src/parser.mly"
                       ( _1 )
# 683 "vcd/src/parser.ml"
               : 'comment_text))
; (fun __caml_parser_env ->
    Obj.repr(
# 194 "vcd/src/parser.mly"
                       ( "" )
# 689 "vcd/src/parser.ml"
               : 'version_text))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 195 "vcd/src/parser.mly"
                       ( _1 )
# 696 "vcd/src/parser.ml"
               : 'version_text))
; (fun __caml_parser_env ->
    Obj.repr(
# 199 "vcd/src/parser.mly"
                       ( "" )
# 702 "vcd/src/parser.ml"
               : 'date_text))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 200 "vcd/src/parser.mly"
                       ( _1 )
# 709 "vcd/src/parser.ml"
               : 'date_text))
(* Entry input *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
|]
let yytables =
  { Parsing.actions=yyact;
    Parsing.transl_const=yytransl_const;
    Parsing.transl_block=yytransl_block;
    Parsing.lhs=yylhs;
    Parsing.len=yylen;
    Parsing.defred=yydefred;
    Parsing.dgoto=yydgoto;
    Parsing.sindex=yysindex;
    Parsing.rindex=yyrindex;
    Parsing.gindex=yygindex;
    Parsing.tablesize=yytablesize;
    Parsing.table=yytable;
    Parsing.check=yycheck;
    Parsing.error_function=parse_error;
    Parsing.names_const=yynames_const;
    Parsing.names_block=yynames_block }
let input (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 1 lexfun lexbuf : Types.t)
