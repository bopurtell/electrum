type token =
  | TOK_BRACKET_O
  | TOK_BRACKET_C
  | TOK_COLON
  | TOK_KW_END
  | TOK_KW_COMMENT
  | TOK_KW_SIM_COMMENT
  | TOK_COMMENT_TEXT of (
# 37 "vcd/src/parser.mly"
        string
# 12 "vcd/src/parser.mli"
)
  | TOK_KW_DATE
  | TOK_DATE_TEXT of (
# 39 "vcd/src/parser.mly"
        string
# 18 "vcd/src/parser.mli"
)
  | TOK_KW_ENDDEFINITIONS
  | TOK_KW_SCOPE
  | TOK_KW_TIMESCALE
  | TOK_KW_UPSCOPE
  | TOK_KW_VAR
  | TOK_KW_VERSION
  | TOK_VERSION_TEXT of (
# 46 "vcd/src/parser.mly"
        string
# 29 "vcd/src/parser.mli"
)
  | TOK_KW_DUMPALL
  | TOK_KW_DUMPOFF
  | TOK_KW_DUMPON
  | TOK_KW_DUMPVARS
  | TOK_KW_BEGIN of (
# 51 "vcd/src/parser.mly"
        Types.Scope.t
# 38 "vcd/src/parser.mli"
)
  | TOK_KW_FORK of (
# 52 "vcd/src/parser.mly"
        Types.Scope.t
# 43 "vcd/src/parser.mli"
)
  | TOK_KW_FUNCTION of (
# 53 "vcd/src/parser.mly"
        Types.Scope.t
# 48 "vcd/src/parser.mli"
)
  | TOK_KW_MODULE of (
# 54 "vcd/src/parser.mly"
        Types.Scope.t
# 53 "vcd/src/parser.mli"
)
  | TOK_KW_TASK of (
# 55 "vcd/src/parser.mly"
        Types.Scope.t
# 58 "vcd/src/parser.mli"
)
  | TOK_TIME_NUMBER of (
# 56 "vcd/src/parser.mly"
        int
# 63 "vcd/src/parser.mli"
)
  | TOK_TIME_UNIT of (
# 57 "vcd/src/parser.mly"
        Types.Time_unit.t
# 68 "vcd/src/parser.mli"
)
  | TOK_VAR_TYPE of (
# 58 "vcd/src/parser.mly"
        Types.Var_type.t
# 73 "vcd/src/parser.mli"
)
  | TOK_HASH
  | TOK_VALUE of (
# 60 "vcd/src/parser.mly"
        Types.Bit.t
# 79 "vcd/src/parser.mli"
)
  | TOK_BIN_NUM of (
# 61 "vcd/src/parser.mly"
        string
# 84 "vcd/src/parser.mli"
)
  | TOK_REAL_NUM of (
# 62 "vcd/src/parser.mly"
        string
# 89 "vcd/src/parser.mli"
)
  | TOK_IDENTIFIER of (
# 63 "vcd/src/parser.mly"
        string
# 94 "vcd/src/parser.mli"
)
  | TOK_DECIMAL_NUM of (
# 64 "vcd/src/parser.mly"
        int
# 99 "vcd/src/parser.mli"
)
  | EOF

val input :
  (Lexing.lexbuf  -> token) -> Lexing.lexbuf -> Types.t
